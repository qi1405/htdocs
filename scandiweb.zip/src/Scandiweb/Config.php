<?php

namespace Scandiweb;

class Config
{
    public static $dbHost = 'mysql6008.site4now.net';
    public static $dbUsername = 'a9d850_bdf_1';
    public static $dbPassword = '1405991473029Qi_';
    public static $dbName = 'db_a9d850_bdf_1';
}
?>